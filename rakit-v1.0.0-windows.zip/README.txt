======================================
  RAKIT - Bahasa Pemrograman Modern
         v1.0.0
======================================

CARA MENGGUNAKAN:
-----------------
1. Tambahkan folder `bin/` ke PATH, atau
2. Jalankan langsung:

   .\rakit.cmd <file.rakit>

   atau

   .\bin\rakit.exe <file.rakit>

PERINTAH:
---------
  rakit run <file>       : Jalankan file .rakit
  rakit build <file>     : Kompilasi file
  rakit doc <file>       : Generate dokumentasi
  rakit optimize <file>  : Optimasi kode
  rakit package install  : Install package
  rakit generate         : Generate binding

DOKUMENTASI:
------------
Buka folder docs/ untuk dokumentasi lengkap.

LISENSI:
--------
Penggunaan bebas. Modifikasi harus dengan izin.
Lihat LICENSE untuk detail.

GITHUB:
-------
https://github.com/zulsyam23-dot/rakit
