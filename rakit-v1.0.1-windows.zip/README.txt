======================================
  RAKIT v1.0.1 - Bahasa Pemrograman Modern
        24 Juni 2026
======================================

CARA MENGGUNAKAN:
-----------------
  .\rakit.cmd build <file.rakit>   : Kompilasi
  .\rakit.cmd doc <file.rakit>     : Generate dokumentasi
  .\rakit.cmd optimize <file.rakit>: Optimasi kode

PERINTAH LENGKAP:
-----------------
  build       : Compile file .rakit
  emit-ir     : Parse dan cetak IR
  init        : Buat project baru
  fmt         : Format kode
  test        : Jalankan test
  dev         : Dev mode (hot reload)
  package     : Kelola packages
  doc         : Generate dokumentasi
  generate    : Generate polyglot bindings
  optimize    : Optimasi file Rakit

DOKUMENTASI:
------------
Buka folder docs/ untuk dokumentasi lengkap.

LISENSI:
--------
Penggunaan bebas. Modifikasi harus dengan izin.

CHANGELOG v1.0.1:
------------------
- [FIX] Parser: struct init {} tidak lagi salah makan { dari if/while block
- [FIX] Tree shaking: perbaiki panic index out of bounds
- [FIX] Type system: tambah dukungan nama tipe Indonesia (Angka, Teks, dll)
- [FIX] Entry point: tree shaking kenali "utama" sebagai entry point juga

GITHUB:
-------
https://github.com/zulsyam23-dot/rakit
