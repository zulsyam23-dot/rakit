@echo off
cd /d "%~dp0"
bin\rakit.exe %*
