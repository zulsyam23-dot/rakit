======================================
  RAKIT v1.0.3 - Bahasa Pemrograman Modern
        26 Juni 2026
======================================

CARA MENGGUNAKAN:
  .\rakit build <file.rakit>       : Kompilasi ke native/WASM
  .\rakit build <file.rakit> --target win32 : Build .exe
  .\rakit dev <file.rakit>         : Dev mode (hot reload)

PERINTAH:
  build, emit-ir, init, fmt, test, dev, package, doc, generate, optimize

CHANGELOG:
- FIX Props komponen bisa diakses langsung di JSX
- FIX Import built-in functions tanpa warning
- NEW Native binary output (PE/ELF) via Brak codegen
- NEW Multi-target: wasm, win32, linux, macos

GITHUB: https://github.com/zulsyam23-dot/rakit
